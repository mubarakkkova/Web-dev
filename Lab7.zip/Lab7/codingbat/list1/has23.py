def has23(nums):
    return 2 == nums[0] or 2 == nums[1] or 3 == nums[0] or 3 == nums[1]
