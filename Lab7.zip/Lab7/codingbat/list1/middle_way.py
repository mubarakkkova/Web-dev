def middle_way(a, b):
    return [a[1], b[1]]