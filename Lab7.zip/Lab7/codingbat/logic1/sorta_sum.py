def sorta_sum(a, b):
    total_sum = a + b
    if 10 <= total_sum <= 19:
        return 20
    
    return total_sum
