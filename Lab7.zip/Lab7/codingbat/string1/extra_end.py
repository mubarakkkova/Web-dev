def extra_end(str):
    return (str[-2] + str[-1]) * 3