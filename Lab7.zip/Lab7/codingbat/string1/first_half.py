def first_half(str):
    h = len(str) / 2
    return str[: h]
