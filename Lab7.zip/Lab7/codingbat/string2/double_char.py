def double_char(str):
    str1 = ""
    for c in str:
        str1 += c*2
    return str1