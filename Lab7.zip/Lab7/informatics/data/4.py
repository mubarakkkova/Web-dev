k = int(input())

hours = k // 3600
minutes = (k % 3600) // 60

print("It is", hours, "hours", minutes, "minutes.")
