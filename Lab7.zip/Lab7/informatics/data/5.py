d = int(input())

hours = d // 30

minutes = (d % 30) * 2

print("It is", hours, "hours", minutes, "minutes.")
