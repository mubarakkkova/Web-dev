
number = int(input())

print("The next number for the number", number, "is", number + 1, end=".\n")

print("The previous number for the number", number, "is", number - 1, end=".")
