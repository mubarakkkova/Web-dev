v = int(input())  
t = int(input())  


distance = v * t  
marker = distance % 109 

print(marker)
