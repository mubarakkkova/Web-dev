n = int(input())
print(sum(i**2 for i in range(1, n + 1)))
