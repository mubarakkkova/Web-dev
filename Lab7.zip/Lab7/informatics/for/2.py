import math

n = int(input())
factorial = math.factorial(n)
print(factorial)
