N = int(input())
result = 2 ** N
print(result)
